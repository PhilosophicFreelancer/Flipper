ADD_SCENE(example_number_input, input_number, InputNumber)
ADD_SCENE(example_number_input, show_number, ShowNumber)
ADD_SCENE(example_number_input, input_max, InputMax)
ADD_SCENE(example_number_input, input_min, InputMin)
