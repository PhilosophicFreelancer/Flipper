#pragma once

// Framework
#include "minunit.h"

#include "test_api.h"

int get_minunit_run(void);

int get_minunit_assert(void);

int get_minunit_status(void);
